import { useState, useRef, useEffect } from "react";
import { Send, Bot, User } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";

interface Message {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
}

export function ChatbotPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hello! I'm your Tenant-Aid assistant. I can help you understand your tenant rights, answer questions about your lease, and guide you on how to handle issues with your landlord. How can I help you today?",
      sender: "bot",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");

    // Simulate bot response
    setTimeout(() => {
      const botResponse = generateBotResponse(inputValue);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: botResponse,
        sender: "bot",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botMessage]);
    }, 1000);
  };

  const generateBotResponse = (userInput: string): string => {
    const input = userInput.toLowerCase();
    
    if (input.includes("evict") || input.includes("eviction")) {
      return "Eviction laws vary by location, but generally, your landlord must provide proper written notice and cannot evict you without a court order. In most cases, you have the right to contest an eviction in court. The notice period is typically 30-60 days for most situations. Would you like more specific information about your situation?";
    } else if (input.includes("deposit") || input.includes("security deposit")) {
      return "Security deposits are protected by law. Your landlord must return your deposit within a specified timeframe (usually 14-30 days) after you move out, minus any legitimate deductions for damages beyond normal wear and tear. They should provide an itemized list of deductions. You have the right to dispute unfair deductions.";
    } else if (input.includes("repair") || input.includes("maintenance")) {
      return "Your landlord is legally required to maintain the property in a habitable condition. This includes working plumbing, heating, electricity, and structural integrity. If repairs aren't made, you should: 1) Submit a written request, 2) Allow reasonable time for repairs, 3) Document everything, 4) Consider withholding rent or making repairs yourself (depending on local laws). Would you like guidance on your specific repair issue?";
    } else if (input.includes("rent") && input.includes("increase")) {
      return "Rent increases are regulated by law. Your landlord typically must provide 30-60 days written notice before raising rent. In rent-controlled areas, there are limits on how much and how often rent can be increased. Your lease terms also dictate when increases can occur. Are you facing an unexpected rent increase?";
    } else if (input.includes("lease") || input.includes("contract")) {
      return "Your lease is a legally binding contract. Make sure you understand all terms before signing. Key things to review: rent amount and due date, lease duration, deposit requirements, maintenance responsibilities, pet policies, and termination conditions. Always get a copy of your signed lease. Do you have questions about specific lease terms?";
    } else if (input.includes("discrimination")) {
      return "Housing discrimination based on race, color, religion, national origin, sex, familial status, or disability is illegal under the Fair Housing Act. This applies to renting, eviction, and lease terms. If you believe you've experienced discrimination, document everything and consider filing a complaint with HUD or contacting a housing attorney.";
    } else {
      return "I understand you're asking about tenant rights. While I can provide general information, I recommend checking your local tenant laws as they can vary significantly by location. You can also visit our 'Your Rights' page for comprehensive information, or submit a detailed report through our 'Report Issue' page for personalized assistance. Is there a specific aspect of tenant rights you'd like to know more about?";
    }
  };

  const quickQuestions = [
    "How do I handle security deposit disputes?",
    "What are my rights regarding repairs?",
    "Can my landlord evict me?",
    "How much notice for rent increase?",
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl mb-4">AI Assistant</h1>
        <p className="text-gray-600">
          Ask questions about your tenant rights and get instant guidance.
        </p>
      </div>

      <Card className="flex flex-col h-[600px]">
        <div className="p-4 border-b bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div>Tenant-Aid AI</div>
              <div className="text-sm text-white/80">Always here to help</div>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${
                  message.sender === "user" ? "flex-row-reverse" : ""
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.sender === "bot"
                      ? "bg-gradient-to-br from-blue-600 to-purple-600"
                      : "bg-gray-300"
                  }`}
                >
                  {message.sender === "bot" ? (
                    <Bot className="w-5 h-5 text-white" />
                  ) : (
                    <User className="w-5 h-5 text-gray-700" />
                  )}
                </div>
                <div
                  className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                    message.sender === "bot"
                      ? "bg-gray-100 text-gray-900"
                      : "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                  }`}
                >
                  {message.text}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {messages.length === 1 && (
          <div className="p-4 border-t bg-gray-50">
            <p className="text-sm text-gray-600 mb-3">Quick questions:</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {quickQuestions.map((question) => (
                <Button
                  key={question}
                  variant="outline"
                  size="sm"
                  className="justify-start h-auto py-2 px-3 text-left whitespace-normal"
                  onClick={() => {
                    setInputValue(question);
                  }}
                >
                  {question}
                </Button>
              ))}
            </div>
          </div>
        )}

        <div className="p-4 border-t">
          <div className="flex gap-2">
            <Input
              placeholder="Ask about your tenant rights..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSend()}
            />
            <Button onClick={handleSend} className="gap-2">
              <Send className="w-4 h-4" />
              Send
            </Button>
          </div>
        </div>
      </Card>

      <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <p className="text-sm text-blue-900">
          <strong>Note:</strong> This AI assistant provides general information only
          and is not a substitute for legal advice. For specific legal issues,
          please consult with a qualified attorney or tenant advocacy organization.
        </p>
      </div>
    </div>
  );
}